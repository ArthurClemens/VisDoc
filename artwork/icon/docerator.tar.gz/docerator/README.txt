You can find documentation for docerator.py at
http://code.google.com/p/docerator/ .

docerator.py needs to be in the same directory as makeicns to work. makeicns
uses the IconFamily library by Troy Stephens
( http://iconfamily.sourceforge.net/ ).
